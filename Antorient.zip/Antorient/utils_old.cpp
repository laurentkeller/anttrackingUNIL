/*
 *  utils.cpp
 *  
 *
 *  Created by Danielle Mersch on 11/20/10.
 *  Copyright 2010 __UNIL__. All rights reserved.
 *
 */

#include "utils.h"

using namespace std;

string time_to_str(const time_t h){
	struct tm* tmp;
	tmp = localtime(&h);
	
	char buf[32];
	strftime(buf, sizeof(buf), "%d/%m/%Y %H:%M:%S", tmp);
	return string(buf);
}