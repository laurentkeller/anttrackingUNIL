/*
 *  @file utils.h
 *  \brief Various fonctions that are useful for many programs
 *
 *  Created by Danielle Mersch on 11/20/10.
 *  Copyright 2010 __UNIL__. All rights reserved.
 *
 */

#include <time.h> 
#include <string>

using namespace std;

/** \fn string time_to_str(const time_t h)
 * \brief Converts unix time to date and seconds
 * \param h Unix time
 * \return Date and time as text
 */
string time_to_str(const time_t h);

