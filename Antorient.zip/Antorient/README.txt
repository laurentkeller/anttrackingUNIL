To install Antorient on linux:

1/ Install wxwidgets library for linux (follow instructions in following website)
http://wiki.wxwidgets.org/Installing_and_configuring_under_Ubuntu

2/ Open command window
3/ Navigate to Antorient folder
4/ Execute the following commands:

make clean
make

